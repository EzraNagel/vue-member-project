<template>
  <div id="table">
    <table class="table is-bordered is-striped is-hoverable is-fullwidth">
      <thead id="table" >
        <td>Last Name</td>
        <td>First Name</td>
        <td>Email Address</td>
        <td>Phone Number</td>
        <td>Edit</td>
      </thead>
      <tbody>
        <tr v-for="person in people">
          <td>
            {{ person.Last_Name }}
          </td>
          <td>
            {{ person.First_Name }}
          </td>
          <td>
            {{ person.Email_address }}
          </td>
          <td>
            {{ person.Mobile_Phone }}
          </td>
          <button class="btn btn-primary btn-space" @click="popup">
            Edit
          </button>
          
        </tr>
      </tbody>
    </table>
  </div>
</template>

<script>

import Modal from '../components/Modal.vue';
import { usePeopleStore } from '../stores/PeopleStore';
import { storeToRefs } from 'pinia';



export default {
  name: 'People',
  props: ['people'],
  components: { Modal },
  setup() {
    const store = usePeopleStore();

    const { people } = storeToRefs(store);

    function fetchPeople() {
      store.fetchPeople();
      return people;
    }

    return { people, fetchPeople, store };
  },
  mounted() {
    this.store.fetchPeople();
  }
}
</script>
