<template>
    <p>Last Name:</p>
    {{ person.LastName }}
    <p>First Name:</p>
    {{ person.FirstName }}
    <p>Date of Birth:</p>
    {{ person.Date_of_Birth }}
    <p>Gender:</p>
    {{ person.Gender }}
    <p>Marital Status:</p>
    {{ person.Marital_Status }}
    <p>Contact_Status:</p>
    {{ person.Contact_Status }}
    <p>Email Address:</p>
    {{ person.Email_address }}
    <p>Mobile Phone:</p>
    {{ person.Mobile_Phone }}
</template>
  
<script>
export default {

}
</script>