import { defineStore } from 'pinia'
import axios from "axios"

export const usePeopleStore = defineStore("people", {

    state: () => ({
        people: [],
    }),

    getters: {
        getPeople(state) {
            return state.people;
        },
    },

    actions: {
        async fetchPeople() {
            try {
                const response = await axios.get('http://csc364chms.cscprof.com/contacts')
                this.people = response.data;
            }
            catch (error) {
                alert(error);
                console.log(error);
            }
        }
    }
});