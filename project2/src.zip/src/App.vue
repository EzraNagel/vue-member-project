<template>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bulma@0.9.4/css/bulma.min.css">
  <section class="section">
    <div class="container">
      <label>Search Names: </label>
      <input type="text" placeholder="Search..">
      
    </div>
    <div>
      <People />
    </div>
  </section>
</template>

<script>

import People from '@/components/People.vue'

export default {
  name: "App",
  components: {
    People,
  },

}
</script>



