<template>
    <div style="padding: 40px" class="about">
        <DonationRegister></DonationRegister>
    </div>
</template>

<script>
import DonationRegister from '../components/DonationRegister.vue';

export default {
    data() {
        return {

        }
    },
    components: {
        DonationRegister
    }
}

</script>