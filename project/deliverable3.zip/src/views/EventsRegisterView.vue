<template>
    <div style="padding: 40px" class="about">
        <EventsRegister></EventsRegister>

    </div>
</template>

<script>
import EventsRegister from '@/components/EventsRegister.vue';

export default {
    data() {
        return {

        }
    },
    components: {
        EventsRegister
    }
}

</script>