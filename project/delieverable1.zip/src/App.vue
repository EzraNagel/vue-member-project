<template>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bulma@0.9.4/css/bulma.min.css">
  <link rel="stylesheet" href="./assets/main.css">
  <section class="hero is-small is-primary">
    <nav class="navbar" role="navigation" aria-label="main navigation">
      <div class="navbar-menu">
        <div class="navbar-start">
          <a class="navbar-item">Home</a>
          <a class="navbar-item">People</a>
          <a class="navbar-item">Events</a>
          <a class="navbar-item">Donations</a>
        </div>
      </div>
    </nav>
  </section>
  <section class="section">
    <div>
      <People />
    </div>
  </section>
</template>

<script>

import People from '@/components/People.vue'
import Events from '@/components/Events.vue'
import Donations from './components/Donations.vue';


export default {
  name: "App",
  components: {
    People,
    Events,
    Donations
},

}
</script>



