<template>
  <h1 class="title">Church Members</h1>
  <div class="columns">
    <div class="search-wrapper column is-one-third"><label>Search Names: </label>
      <input class="form-control" type="text" name="searchQuery" v-model="searchQuery" placeholder="Search.." />
    </div>
    <div class="column">
      <p>Sort Last Name A-Z</p>
      <o-switch @click="filterLastName" />
    </div>
    <div class="column">
      <p>Sort First Name A-Z</p>
      <o-switch @click="filterFirstName" />
    </div>
    <!-- <div class="column">
      <p>Only Active</p>
      <o-switch @click="filterStatus" />
    </div> -->


  </div>
  <div id="table">
    <table class="table is-bordered is-striped is-hoverable is-fullwidth">
      <thead id="table">
        <td>Last Name</td>
        <td>First Name</td>
        <td>Email Address</td>
        <td>Phone Number</td>
        <td>Details</td>
      </thead>
      <tbody>
        <tr v-for="person in resultQuery()">
          <td>
            {{ person.Last_Name }}
          </td>
          <td>
            {{ person.First_Name }}
          </td>
          <td>
            {{ person.Email_address }}
          </td>
          <td>
            {{ person.Mobile_Phone }}
          </td>
          <td>
            <button size="medium" id="button" @click="isImageModalActive = true, person1 = person">
              Details
            </button>
          </td>

        </tr>
      </tbody>
    </table>
  </div>

  <o-modal v-model:active="isImageModalActive" :width="640" scroll="clip">
    <div style="padding: 10px;">
      <p>{{ person1.First_Name }} {{ person1.Last_Name }}</p>
      <p>Date of Birth: {{ person1.Date_of_Birth }}</p>
      <p>Gender: {{ person1.Gender }}</p>
      <p>Marital Status: {{ person1.Marital_Status }}</p>
      <p>Contact Status: {{ person1.Contact_Status }}</p>
      <p>Email Address: {{ person1.Email_address }}</p>
      <p>Mobile Phone: {{ person1.Mobile_Phone }}</p>
    </div>
  </o-modal>
</template>

<script>

import { defineComponent, ref } from 'vue'
import { usePeopleStore } from '../stores/PeopleStore';
import { storeToRefs } from 'pinia';




export default {
  name: 'People',
  props: ['people'],
    
  methods: {
    resultQuery(){
      return this.filteredPeople.filter((entry) => this.filteredPeople.length ? Object.keys(this.filteredPeople[0]).some(key => ('' + entry[key]).toLowerCase().includes(this.searchQuery)) : true)
    },
    filterFirstName() {
      if (this.firstNameFilter) {
        this.filteredPeople = this.filteredPeople.sort((a, b) => {
          if (a.First_Name < b.First_Name) {
            return -1;
          }
        })
        this.firstNameFilter = false;
      }
      else {
        this.filteredPeople = this.filteredPeople.sort((a, b) => {
          if (a.First_Name > b.First_Name) {
            return -1;
          }
        })
        this.firstNameFilter = true;
      }
    },
    filterLastName() {
      if (this.lastNameFilter) {
        this.filteredPeople = this.filteredPeople.sort((a, b) => {
          if (a.Last_Name < b.Last_Name) {
            return -1;
          }
        })
        this.lastNameFilter = false;
      }
      else {
        this.filteredPeople = this.filteredPeople.sort((a, b) => {
          if (a.Last_Name > b.Last_Name) {
            return -1;
          }
        })
        this.lastNameFilter = true;
      }
    },
    // filterStatus(){
    //   if (this.statusFilter){
    //     for(const person of filteredPeople){

    //     }
    //   }
    // }


  },

  setup() {
    const isImageModalActive = ref(false);
    const isCardModalActive = ref(false);
    const store = usePeopleStore();
    const firstNameFilter = ref(false);
    const lastNameFilter = ref(false);
    // const statusFilter = ref(false);
    const { people } = storeToRefs(store);
    const filteredPeople = people;
    const person1 = people[0];
    let searchQuery = ref('')
    function fetchPeople() {
      store.fetchPeople();
      return people;
    }
    
    return { people, fetchPeople, store, isImageModalActive, isCardModalActive, person1, filteredPeople, firstNameFilter, lastNameFilter, searchQuery};
  },
  mounted() {
    this.store.fetchPeople();
  },


}
</script>
